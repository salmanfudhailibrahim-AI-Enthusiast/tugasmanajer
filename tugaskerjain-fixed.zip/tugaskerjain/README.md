# Tugas Kampus (PemantauTugas)

Aplikasi Android untuk memantau tugas dari web kampus (Moodle/Canvas), membaca PDF materi di dalam aplikasi,
meringkas / membuat soal latihan / mengerjakan tugas dengan AI per mata kuliah, dan mengumpulkan tugas (Moodle).

## Struktur
- `app/` : satu-satunya modul Android (`com.android.application`). Source ada di `app/src/main`.
- `.github/workflows/build.yml` : build APK otomatis + rilis (dibaca fitur update di aplikasi).

## Secrets GitHub (opsional, supaya APK bisa menimpa versi lama)
- `KEYSTORE_B64` : hasil `base64 -w0 update.jks` (satu baris)
- `KEYSTORE_PASSWORD` : password keystore (alias harus `key0`)
Tanpa secret ini build tetap jalan memakai kunci debug.
